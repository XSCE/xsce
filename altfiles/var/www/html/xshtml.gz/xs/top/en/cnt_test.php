<?php phpinfo();?>

