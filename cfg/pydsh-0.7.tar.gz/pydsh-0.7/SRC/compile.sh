#!/bin/bash

# ------------------------------------------------------------------------------
# Filename:      compile.sh
# Version:       0.1a
# Maintainer:    Dave V  <dvehrs (at) gmail.com>
# Created:       12 Aug 2011 03:09:00 PM
# Last Modified: 12 Aug 2011 03:10:38 PM by Dave,,,
# Copyright:     © 2011 Dave V
#
# ------------------------------------------------------------------------------

python -mcompileall pydsh.py 
