#!/bin/bash
# ------------------------------------------------------------------------------
# Maintainer:    Dave Vehrs <dvehrs(at)gmail.com>
# Created:       29 Mar 2005 10:34:42 PM
# Last Modified: 12 Aug 2011 03:37:30 PM by Dave,,,
# Copyright:     © 2005-2011 Dave Vehrs
#
#                This program is free software; you can redistribute it and/or
#                modify it under the terms of the GNU General Public License as
#                published by the Free Software Foundation; either version 2 of
#                the License, or (at your option) any later version.
#
#                This program is distributed in the hope that it will be useful,
#                but WITHOUT ANY WARRANTY; without even the implied warranty of
#                MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#                GNU General Public License for more details.
#
#                You should have received a copy of the GNU General Public
#                License along with this program; if not, write to the Free
#                Software Foundation, Inc., 59 Temple Place, Suite 330, 
#                Boston, MA 02111-1307 USA _OR_ download at copy at 
#                http://www.gnu.org/licenses/licenses.html#TOCGPL
# ------------------------------------------------------------------------------
install=1

: << HELP_STEXT
    --install        Install Pydsh
    --uninstall      Uninstall Pydsh
    <anything else>  Display this text.
HELP_STEXT

function display_shelp {  
	echo; echo "Usage $0 [options]"
	sed --silent -e '/HELP_STEXT$/,/^HELP_STEXT/p' "$0" | sed -e '/HELP_STEXT/d'
}

# Root (UID 0) test                               
if [ "$UID" -ne "0" ] ; then
    echo -e "\n\nYou must be root to run this script."
    exit 1
fi 

if [ $# -eq 0 ] ; then
    display_shelp
    exit 1
fi

while [ $# -ge 1 ] ; do
	case $1 in 
        --install         ) install=1                  ; shift        ;;
        --uninstall       ) install=0                  ; shift        ;;
		*                 ) display_shelp              ; exit 1        ;; 
	esac
done

# Remove prexisting copies and/or uninstall mode.
echo "Removing any old versions of pydsh.py and the manpages"
rm -f /usr/local/bin/pydsh.py
rm -f  /usr/share/man/man8/pydsh.8.gz
rm -f /usr/share/man/man8/pydcp.8.gz
rm -f /usr/local/bin/pydsh
rm -f /usr/local/bin/pydcp

if [ $install -eq 0 ] ; then
    exit 0
fi

install_bin=$(which install)
echo "Installing pydsh.py and manpages."
if [ -e $install_bin ] ; then
    install --owner=root --group=root --mode 755 SRC/pydsh.py /usr/local/bin
    install --owner=root --group=root --mode 644 DOC/pydsh.8.gz /usr/share/man/man8
    install --owner=root --group=root --mode 644 DOC/pydcp.8.gz /usr/share/man/man8
else
    cp SRC/pydsh.py /usr/local/bin
    chown root.root /usr/local/bin/pydsh.py
    chmod 775 /usr/local/bin/pydsh.py

    cp DOC/pydsh.8.gz /usr/share/man/man8/pydsh.8.gz
    chown root.root /usr/share/man/man8/pydsh.8.gz
    chmod 644 /usr/share/man/man8/pydsh.8.gz

    cp DOC/pydcp.8.gz /usr/share/man/man8/pydcp.8.gz
    chown root.root /usr/share/man/man8/pydcp.8.gz
    chmod 644 /usr/share/man/man8/pydcp.8.gz
fi

echo "Making necessary symbolic links"
ln -s /usr/local/bin/pydsh.py /usr/local/bin/pydsh
ln -s /usr/local/bin/pydsh.py /usr/local/bin/pydcp

# Install config files.
if [ ! -e /usr/local/etc/pydsh/ ] || [ ! -e /usr/local/etc/pydsh/groups ] ; then
    echo "Creating configuration directories."
    mkdir -p /usr/local/etc/pydsh/groups
    chown -R root.root /usr/local/etc/pydsh
    chmod -R 755 /usr/local/etc/pydsh 
    if [ -e /etc/dsh/group/* ] ; then
        echo "Copying existing group files from DSH configuration."
        cp /etc/dsh/group/* /usr/local/etc/pydsh/groups/
    fi
fi

if [ ! -e /usr/local/etc/pydsh/pydshrc ]  ; then
    if [ -e $install_bin ] ; then
        install --owner=root --group=root --mode=644 CONF/pydshrc /usr/local/etc/pydsh
    else
        cp CONF/pydshrc /usr/local/etc/pydsh/
        chown root.root /usr/local/etc/pydsh/pydshrc
        chmod 644 /usr/local/etc/pydsh/pydshrc
    fi
fi

if [ ! -e /usr/local/etc/pydsh/groups/all ] ; then  
    echo "Creating default all host group file (with one member: localhost)." 
    echo localhost > /usr/local/etc/pydsh/groups/all
fi

